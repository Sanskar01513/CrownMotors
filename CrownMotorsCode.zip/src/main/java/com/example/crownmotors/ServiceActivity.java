package com.example.crownmotors;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;

import com.example.crownmotors.DBService;
import com.example.crownmotors.ServiceAdapter;
import com.example.crownmotors.ServiceBooking;

import java.util.ArrayList;

public class ServiceActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ServiceAdapter serviceAdapter;
    private ArrayList<ServiceBooking> serviceBookings;
    private DBService dbService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service);

        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        serviceBookings = new ArrayList<>();
        dbService = new DBService(this);

        // Retrieve service bookings from the database
        serviceBookings = dbService.getAllServiceBookings();

        // Set up RecyclerView adapter
        serviceAdapter = new ServiceAdapter(serviceBookings);
        recyclerView.setAdapter(serviceAdapter);
    }
}
