package com.example.crownmotors;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import java.util.ArrayList;

public class AboutActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AboutAdapter aboutAdapter;
    private ArrayList<AboutBooking> aboutBookings;
    private DBAbout dbAbout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        aboutBookings = new ArrayList<>();
        dbAbout = new DBAbout(this);

        // Retrieve about bookings from the database
        aboutBookings = dbAbout.getAllAboutBookings();

        // Set up RecyclerView adapter
        aboutAdapter = new AboutAdapter(aboutBookings, dbAbout);
        recyclerView.setAdapter(aboutAdapter);
    }
}
