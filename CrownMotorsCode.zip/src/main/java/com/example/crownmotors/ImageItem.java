package com.example.crownmotors;

public class ImageItem {
    private int photoThumbnail;
    private String photoTitle;
    private String brandName;
    private int brandImage;

    public int getPhotoThumbnail() {
        return photoThumbnail;
    }

    public String getPhotoTitle() {
        return photoTitle;
    }

    public String getBrandName() {
        return brandName;
    }

    public int getBrandImage() {
        return brandImage;
    }

    public ImageItem(int photoThumbnail, String photoTitle, String brandName, int brandImage) {
        this.photoThumbnail = photoThumbnail;
        this.photoTitle = photoTitle;
        this.brandName = brandName;
        this.brandImage = brandImage;
    }
}
