package com.example.crownmotors;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.example.crownmotors.DBHelper;
import java.util.ArrayList;

public class NewsActivity extends AppCompatActivity {

    ArrayList<String> nameList, emailList, ageList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        DBHelper dbHelper = new DBHelper(this);

        nameList = new ArrayList<>();
        emailList = new ArrayList<>();
        ageList = new ArrayList<>();
        Cursor cursor = dbHelper.getdata();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                nameList.add(cursor.getString(0));
                emailList.add(cursor.getString(1));
                ageList.add(cursor.getString(2));
            } while (cursor.moveToNext());
            cursor.close();
        }

        MyAdapter adapter = new MyAdapter(nameList, emailList, ageList);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter.setOnItemClickListener(new MyAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                Intent intent = new Intent(NewsActivity.this, DetailActivity.class);
                intent.putExtra("name", nameList.get(position));
                intent.putExtra("email", emailList.get(position));
                intent.putExtra("age", ageList.get(position));
                startActivity(intent);
            }
        });
    }
}
