package com.example.crownmotors;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


public class HomeFragment extends Fragment {

    private List<ImageItem> imageList;
    private RecyclerView homeRecyclerView;
    private ImageAdapter imageAdapter;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        imageList = generateImageItems();

        homeRecyclerView = rootView.findViewById(R.id.homeRecyclerView);
        homeRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        imageAdapter = new ImageAdapter(imageList);
        homeRecyclerView.setAdapter(imageAdapter);

        return rootView;
    }

    private List<ImageItem> generateImageItems(){
        List<ImageItem> imageItems = new ArrayList<>();
        imageItems.add(new ImageItem(R.drawable.dodge_durango_24, "Durango 2024 Model", "Dodge  starting from $50000", R.drawable.dodge_logo));
        imageItems.add(new ImageItem(R.drawable.cadillac_2024, "Cadillac 2024 Model", "Cadillac  starting from $55000", R.drawable.cadillac_logo));
        imageItems.add(new ImageItem(R.drawable.enclave_avenir_2024, "Enclave Avenir 2024 Model", "Buick  starting from $50000", R.drawable.buick_logo));
        imageItems.add(new ImageItem(R.drawable.compass, "Compass Latitude LUX 2024 Model", "Jeep  starting from $50000", R.drawable.jeep));
        imageItems.add(new ImageItem(R.drawable.ram, "RAM 1500 Rebel 2024 Model", "RAM  starting from $50000", R.drawable.ram_logo));
        imageItems.add(new ImageItem(R.drawable.atlas, "Atlas 2.0T SEL 2024 Model", "Volkswagen  starting from $50000", R.drawable.vw));
        imageItems.add(new ImageItem(R.drawable.camry, "Camry Hybrid 2024 Model", "Toyota  starting from $34000", R.drawable.toyota));
        imageItems.add(new ImageItem(R.drawable.supra, "GR Supra 2024 Model", "Toyota  starting from $50000", R.drawable.toyota));
        imageItems.add(new ImageItem(R.drawable.lc, "Land Cruiser 2024 Model", "Toyota  starting from $50000", R.drawable.toyota));

        return imageItems;
    }
}