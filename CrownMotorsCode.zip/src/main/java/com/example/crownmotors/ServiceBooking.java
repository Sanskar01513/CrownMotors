package com.example.crownmotors;

public class ServiceBooking {
    private String ownerName;
    private String carName;
    private String serviceType;

    public ServiceBooking(String ownerName, String carName, String serviceType) {
        this.ownerName = ownerName;
        this.carName = carName;
        this.serviceType = serviceType;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }
}
