package com.example.crownmotors;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ImageViewHolder> {

    private List<ImageItem> imageList;

    public ImageAdapter(List<ImageItem> imageList) {
        this.imageList = imageList;
    }

    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_photo, parent, false);
        return new ImageViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder holder, int position) {
        ImageItem imageItem = imageList.get(position);
        holder.photoThumbnail.setImageResource(imageItem.getPhotoThumbnail());
        holder.photoTitle.setText(imageItem.getPhotoTitle());
        holder.brandName.setText(imageItem.getBrandName());
        holder.brandImage.setImageResource(imageItem.getBrandImage());
    }

    @Override
    public int getItemCount() {
        return imageList.size();
    }

    public static class ImageViewHolder extends RecyclerView.ViewHolder{
        ImageView photoThumbnail;
        TextView photoTitle;
        TextView brandName;
        ImageView brandImage;

        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            photoThumbnail = itemView.findViewById(R.id.photoThumbnail);
            photoTitle = itemView.findViewById(R.id.photoTitle);
            brandName = itemView.findViewById(R.id.brandName);
            brandImage = itemView.findViewById(R.id.brandImage);

        }
    }
}
