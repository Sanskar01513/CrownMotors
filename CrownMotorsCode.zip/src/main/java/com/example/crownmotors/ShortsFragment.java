package com.example.crownmotors;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class ShortsFragment extends Fragment {

    private ViewPager2 viewPager2;
    private List<ShortsData> shortsDataList;
    private ShortsAdapter shortsAdapter;

    public ShortsFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_shorts, container, false);

        shortsDataList = new ArrayList<>();
        viewPager2 = rootView.findViewById(R.id.viewPager2);

        shortsDataList.add(new ShortsData("android.resource://" + getActivity().getPackageName() + "/" + R.raw.tesla, "Tesla", "Model X Ice Challenge", R.drawable.tesla_logo));
        shortsDataList.add(new ShortsData("android.resource://" + getActivity().getPackageName() + "/" + R.raw.ferrari, "Ferrari", "Ferrari 900Nm Torque Engine", R.drawable.ferrari_logo));
        shortsDataList.add(new ShortsData("android.resource://" + getActivity().getPackageName() + "/" + R.raw.lamborghini, "Lamborghini", "New Lamborghini in Action", R.drawable.lamborghini_logo));
        shortsDataList.add(new ShortsData("android.resource://" + getActivity().getPackageName() + "/" + R.raw.astonmartin, "Astonmartin", "Take yourself to limit", R.drawable.astonmartin_logo));
        shortsDataList.add(new ShortsData("android.resource://" + getActivity().getPackageName() + "/" + R.raw.audi, "Audi", "Audi A6 Avant e-tron visuals", R.drawable.audi_logo));
        shortsDataList.add(new ShortsData("android.resource://" + getActivity().getPackageName() + "/" + R.raw.bentley, "Bentley", "Bentley Bantayga S in wild", R.drawable.b));
        shortsDataList.add(new ShortsData("android.resource://" + getActivity().getPackageName() + "/" + R.raw.rollroyce, "Rollroyce", "Rolls Royce SUV in the Desert", R.drawable.rr));
        shortsDataList.add(new ShortsData("android.resource://" + getActivity().getPackageName() + "/" + R.raw.toyota, "Toyota", "Toyota Corolla Crash Test", R.drawable.toyota));

        shortsAdapter = new ShortsAdapter(shortsDataList);
        viewPager2.setAdapter(shortsAdapter);

        return rootView;

    }

    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }

    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }
}