package com.example.crownmotors;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class DBService extends SQLiteOpenHelper {

    public DBService(Context context) {
        super(context, "ServiceData.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("CREATE TABLE ServiceDetails (id INTEGER PRIMARY KEY AUTOINCREMENT, owner_name TEXT, car_name TEXT, service_type TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int oldVersion, int newVersion) {
        DB.execSQL("DROP TABLE IF EXISTS ServiceDetails");
        onCreate(DB);
    }

    public boolean insertServiceData(String ownerName, String carName, String serviceType) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("owner_name", ownerName);
        contentValues.put("car_name", carName);
        contentValues.put("service_type", serviceType);
        long result = db.insert("ServiceDetails", null, contentValues);
        return result != -1;
    }

    public ArrayList<ServiceBooking> getAllServiceBookings() {
        ArrayList<ServiceBooking> serviceBookings = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM ServiceDetails", null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int ownerNameIndex = cursor.getColumnIndex("owner_name");
                int carNameIndex = cursor.getColumnIndex("car_name");
                int serviceTypeIndex = cursor.getColumnIndex("service_type");
                if (ownerNameIndex != -1 && carNameIndex != -1 && serviceTypeIndex != -1) {
                    String ownerName = cursor.getString(ownerNameIndex);
                    String carName = cursor.getString(carNameIndex);
                    String serviceType = cursor.getString(serviceTypeIndex);
                    ServiceBooking serviceBooking = new ServiceBooking(ownerName, carName, serviceType);
                    serviceBookings.add(serviceBooking);
                } else {
                    // Handle the case where column index is -1 (column not found)
                    // Log an error message or throw an exception
                }
            }
            cursor.close();
        }
        return serviceBookings;
    }

    public void deleteServiceBooking(ServiceBooking serviceBooking) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("ServiceDetails", "owner_name = ? AND car_name = ? AND service_type = ?",
                new String[]{serviceBooking.getOwnerName(), serviceBooking.getCarName(), serviceBooking.getServiceType()});
        db.close();
    }


}
