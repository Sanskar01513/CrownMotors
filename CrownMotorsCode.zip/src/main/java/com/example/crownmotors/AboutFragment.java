package com.example.crownmotors;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class AboutFragment extends Fragment {
    private EditText nameEditText, emailEditText, phoneEditText, commentEditText;
    private Button sendButton;
    private ImageButton backButton;

    public AboutFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_about, container, false);

        // Initialize UI components
        nameEditText = view.findViewById(R.id.name);
        emailEditText = view.findViewById(R.id.email);
        phoneEditText = view.findViewById(R.id.phone);
        commentEditText = view.findViewById(R.id.comment);
        sendButton = view.findViewById(R.id.btnInsert);
        backButton = view.findViewById(R.id.btnBack);

        // Set click listener for the send button
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get data entered by the user
                String name = nameEditText.getText().toString();
                String email = emailEditText.getText().toString();
                String phone = phoneEditText.getText().toString();
                String comment = commentEditText.getText().toString();

                // Create an instance of DBAbout and insert data into the database
                DBAbout dbAbout = new DBAbout(getContext());
                boolean isInserted = dbAbout.insertAboutData(name, email, phone, comment);

                // Show toast message based on insertion status
                if (isInserted) {
                    Toast.makeText(getContext(), "Data Inserted Successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "Failed to Insert Data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to MainActivity
                Intent intent = new Intent(getActivity(), MainActivity.class);
                startActivity(intent);
            }
        });

        return view;
    }
}
