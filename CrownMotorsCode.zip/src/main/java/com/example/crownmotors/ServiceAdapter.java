package com.example.crownmotors;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class ServiceAdapter extends RecyclerView.Adapter<ServiceAdapter.ViewHolder> {
    private ArrayList<ServiceBooking> serviceBookings;

    public ServiceAdapter(ArrayList<ServiceBooking> serviceBookings) {
        this.serviceBookings = serviceBookings;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_service_booking, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ServiceBooking serviceBooking = serviceBookings.get(position);
        holder.bind(serviceBooking);
    }

    @Override
    public int getItemCount() {
        return serviceBookings.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView textName, textEmail, textAge;
        private Button serviceDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textName = itemView.findViewById(R.id.textname);
            textEmail = itemView.findViewById(R.id.textemail);
            textAge = itemView.findViewById(R.id.textage);
            serviceDelete = itemView.findViewById(R.id.serviceDelete);

            serviceDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        ServiceBooking serviceBooking = serviceBookings.get(position);
                        // Delete the record from the database
                        DBService dbService = new DBService(itemView.getContext());
                        dbService.deleteServiceBooking(serviceBooking);
                        // Remove the item from the list and notify the adapter
                        serviceBookings.remove(position);
                        notifyItemRemoved(position);
                    }
                }
            });
        }

        public void bind(ServiceBooking serviceBooking) {
            textName.setText(serviceBooking.getOwnerName());
            textEmail.setText(serviceBooking.getCarName());
            textAge.setText(serviceBooking.getServiceType());
        }
    }
}

