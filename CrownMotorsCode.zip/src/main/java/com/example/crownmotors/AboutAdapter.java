package com.example.crownmotors;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AboutAdapter extends RecyclerView.Adapter<AboutAdapter.ViewHolder> {
    private ArrayList<AboutBooking> aboutBookings;
    private DBAbout dbAbout;

    public AboutAdapter(ArrayList<AboutBooking> aboutBookings, DBAbout dbAbout) {
        this.aboutBookings = aboutBookings;
        this.dbAbout = dbAbout;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_about_booking, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AboutBooking aboutBooking = aboutBookings.get(position);
        holder.bind(aboutBooking);
    }

    @Override
    public int getItemCount() {
        return aboutBookings.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView textName, textEmail, textPhone, textComment;
        private Button markDoneButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textName = itemView.findViewById(R.id.textname);
            textEmail = itemView.findViewById(R.id.textemail);
            textPhone = itemView.findViewById(R.id.textphone);
            textComment = itemView.findViewById(R.id.textcomment);
            markDoneButton = itemView.findViewById(R.id.serviceDelete);

            markDoneButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        AboutBooking aboutBooking = aboutBookings.get(position);
                        // Delete the record from the database
                        dbAbout.deleteAboutBooking(aboutBooking);
                        // Remove the item from the list and notify the adapter
                        aboutBookings.remove(position);
                        notifyItemRemoved(position);
                    }
                }
            });
        }

        public void bind(AboutBooking aboutBooking) {
            textName.setText(aboutBooking.getName());
            textEmail.setText(aboutBooking.getEmail());
            textPhone.setText(aboutBooking.getPhone());
            textComment.setText(aboutBooking.getComment());
        }
    }
}
