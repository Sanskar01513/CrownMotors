package com.example.crownmotors;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public class ServiceFragment extends Fragment {

    public ServiceFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_service, container, false);

        EditText ownerNameEditText = view.findViewById(R.id.name);
        EditText carNameEditText = view.findViewById(R.id.car);
        EditText serviceTypeEditText = view.findViewById(R.id.service);
        Button bookServiceButton = view.findViewById(R.id.btnInsert);

        bookServiceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ownerName = ownerNameEditText.getText().toString();
                String carName = carNameEditText.getText().toString();
                String serviceType = serviceTypeEditText.getText().toString();

                boolean isInserted = new DBService(getContext()).insertServiceData(ownerName, carName, serviceType);
                if (isInserted) {
                    Toast.makeText(getContext(), "Service Booked, Visit Today", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "Failed to book service", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return view;
    }
}
